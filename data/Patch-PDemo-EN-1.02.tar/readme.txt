Patch Hopkins PLAYABLE DEMO.(For version 1.00) 
New Version = 1.02

Change :

Fix these bugs :

fix a Segfault error bug.
fix a timer bug. 

Save all files in the home repertory of the user.
Fix the bug with the ESC KEY.
Fix the bugs in the Break Out game.



You can replace the Hopkins-PDemo.bin file by this new
Hopkins-Pdemo.bin file.
